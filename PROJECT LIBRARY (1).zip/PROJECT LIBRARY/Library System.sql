-- Active: 1696419593212@@127.0.0.1@3306
CREATE DATABASE LibrarySystem;
use LibrarySystem;



create Table Borrower(BorrowerID VARCHAR(10) PRIMARY KEY, BorrowerName VARCHAR(35), PhoneNumber INT, Email VARCHAR(25), Programme VARCHAR(15));
create table Books(BookID VARCHAR(10) PRIMARY KEY, title VARCHAR(25), Publisher VARCHAR(25), NumberOfCopies INT, AvailabiltyStatus VARCHAR(10));
create table Librarian(LibrarianID VARCHAR(10) PRIMARY KEY, Fname VARCHAR(15), Lname VARCHAR(20), WorkingHours VARCHAR(15) NOT NULL);
create table LoanTracker(LoanID VARCHAR(10) PRIMARY KEY, BorrowerID VARCHAR(10), BookID VARCHAR(10), AvailableNumber INT, LoanDate VARCHAR(10), TimeBorrowed VARCHAR(10), ReturnDate VARCHAR(10), LibrarianID VARCHAR(10));
create table Renewal(RenewalID VARCHAR(10) PRIMARY KEY, LoanID VARCHAR(10), RenewalDate VARCHAR(10), RenewalTime VARCHAR(10), NewReturnDate VARCHAR(15), LibrarianID VARCHAR(10));
create table Penalty(PenaltyCode VARCHAR(10) PRIMARY KEY, Reason VARCHAR(40), BorrowerID VARCHAR(10), BookID VARCHAR(10));
create table ReturnedBooks(ReturnID VARCHAR(10) PRIMARY KEY, LoanID VARCHAR(10), ReturnDate VARCHAR(12), ReturnTime VARCHAR(10), BookCondition VARCHAR(30), LibrarianID VARCHAR(10));
create table Resources(ResourceID VARCHAR(10) PRIMARY KEY, Title VARCHAR(20), Author VARCHAR(30), Format VARCHAR(20), AvailabilityStatus VARCHAR(15));
create table User(UserID VARCHAR(10) PRIMARY KEY, Names VARCHAR(30), Email VARCHAR(25) NOT NULL, SecretPassword VARCHAR(30), MembershipStatus VARCHAR(15));
create table Payment(paymentID VARCHAR(20) PRIMARY KEY, DateOfPayment VARCHAR(20), MethodOfPayment VARCHAR(20), Subscription VARCHAR(20));

show tables;

ALTER TABLE LoanTracker add FOREIGN KEY(BorrowerID) REFERENCES Borrower(BorrowerID);
ALTER TABLE LoanTracker add FOREIGN KEY(BookID) REFERENCES Books(BookID);
ALTER TABLE LoanTracker add FOREIGN KEY(LibrarianID) REFERENCES Librarian(LibrarianID);
ALTER TABLE Renewal add FOREIGN KEY(LoanID) REFERENCES LoanTracker(LoanID);
ALTER TABLE Renewal add FOREIGN KEY(LibrarianID) REFERENCES Librarian(LibrarianID);
ALTER TABLE Penalty add FOREIGN KEY(BorrowerID) REFERENCES Borrower(BorrowerID);
ALTER TABLE Penalty add FOREIGN KEY(BookID) REFERENCES Books(BookID);
ALTER TABLE ReturnedBooks add FOREIGN KEY(LoanID) REFERENCES LoanTracker(LoanID);
ALTER TABLE ReturnedBooks add FOREIGN KEY(LibrarianID) REFERENCES Librarian(LibrarianID);
ALTER TABLE Payment add column UserID VARCHAR(10);
ALTER TABLE Payment add FOREIGN KEY(UserID) REFERENCES User(UserID);


ALTER TABLE Books MODIFY COLUMN AvailabiltyStatus VARCHAR(15);



ALTER TABLE Borrower add constraint borrow_id UNIQUE(PhoneNumber);
ALTER TABLE User add constraint user_id UNIQUE(Email);



desc payment;
desc Borrower;
desc Librarian;
desc LoanTracker;
desc User;
desc Renewal;



INSERT INTO Borrower VALUES('B001', 'Aber Charity', 0787612230, 'abercharity11@gmail.com', 'BSIT');
INSERT INTO Borrower VALUES('B002', 'Wasswa Elijah', 0757612230, 'W.Elijah@gmail.com', 'BCSC');
INSERT INTO Borrower VALUES('B003', 'Nakku Brian', 0700368392, 'Nakku90@gmail.com', 'DIT');
INSERT INTO Borrower VALUES('B004', 'John Pol', 0787694621, 'JPol40@gmail.com', 'BSIT');
INSERT INTO Borrower VALUES('B005', 'Moses Kibuuka', 0787614993, 'mosesk@gmail.com', 'LAW');
INSERT INTO Borrower VALUES('B006', 'Kato Brian', 0787797550, 'katobrian12@gmail.com', 'BBA');
SELECT * FROM Borrower;

UPDATE Borrower SET BorrowerID = 'BR01' WHERE Email = 'abercharity11@gmail.com';
UPDATE Borrower SET BorrowerID = 'BR02' WHERE Email = 'W.Elijah@gmail.com';
UPDATE Borrower SET BorrowerID = 'BR03' WHERE Email = 'Nakku90@gmail.com';
UPDATE Borrower SET BorrowerID = 'BR04' WHERE Email = 'JPol40@gmail.com';
UPDATE Borrower SET BorrowerID = 'BR05' WHERE Email = 'mosesk@gmail.com';
UPDATE Borrower SET BorrowerID = 'BR06' WHERE Email = 'katobrian12@gmail.com';





INSERT INTO Books VALUES('B001', 'The Great Gatsby', 'Scribner', 5, 'Available');
INSERT INTO Books VALUES('B002', '1984', 'Secker & Warburg', 3, 'Available');
INSERT INTO Books VALUES('B003', 'To Kill a Mockingbird', 'J.B. Lippincott', 2, 'Available');
INSERT INTO Books VALUES('B004', 'Pride and Prejudice', 'T. Egerton', 9, 'Available');
INSERT INTO Books VALUES('B005', 'The Catcher in the Rye', 'Little, Brown', 15, 'Available');
INSERT INTO Books VALUES('B006', 'Moby Dick', 'Harper & Brothers', 3, 'Available');
INSERT INTO Books VALUES('B007', 'War and Peace', 'The Russian Messenger', 2, 'Unavailable');
INSERT INTO Books VALUES('B008', 'The Odyssey', 'Penguin Classics', 6, 'Available');
INSERT INTO Books VALUES('B009', 'Brave New World', 'Chatto & Windus', 5, 'Available');
INSERT INTO Books VALUES('B010', 'The Hobbit', 'George Allen & Unwin', 1, 'Unavailable');
SELECT * FROM Books;





INSERT INTO Librarian VALUES('L001', 'Ageno', 'Sarah', '7am-1pm');
INSERT INTO Librarian VALUES('L002', 'Ngabo', 'Oscar', '2pm-9pm');
SELECT * FROM Librarian;



INSERT INTO LoanTracker VALUES('LN01', 'BR01', 'B005', 14, '09-06-2024', '10:30 AM', '15-06-2024', 'L001');
INSERT INTO LoanTracker VALUES('LN02', 'BR06', 'B003', 1, '30-06-2024', '02:15 PM', '06-07-2024', 'L002');
INSERT INTO LoanTracker VALUES('LN03', 'BR06', 'B009', 2, '30-06-2024', '02:15 PM', '06-07-2024', 'L002');
INSERT INTO LoanTracker VALUES('LN04', 'BR03', 'B004', 8, '10-07-2024', '01:00 PM', '17-07-2024', 'L001');
SELECT * FROM loanTracker;


INSERT INTO Renewal VALUES('BR06', 'LN03', '04-07-2024', '3:30PM', '13-07-2024', 'L002');
SELECT * FROM Renewal;













  